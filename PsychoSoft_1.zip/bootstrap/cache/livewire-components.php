<?php return array (
  'edit-paciente-table' => 'App\\Http\\Livewire\\EditPacienteTable',
  'expediente-medico' => 'App\\Http\\Livewire\\ExpedienteMedico',
  'ficha-paciente' => 'App\\Http\\Livewire\\FichaPaciente',
  'form-edit-expediente' => 'App\\Http\\Livewire\\FormEditExpediente',
  'form-edit-ficha-paciente' => 'App\\Http\\Livewire\\FormEditFichaPaciente',
  'h-d-paciente-table' => 'App\\Http\\Livewire\\HDPacienteTable',
  'pacientes-table' => 'App\\Http\\Livewire\\PacientesTable',
);


<?php $__env->startSection('title', 'Calendario'); ?>

<?php $__env->startSection('content'); ?>
    

    <div id='calendar' class="bg-white card pt-2 pb-2 pl-4 pr-4 m-auto" style="border-radius: 15px;"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href=" <?php echo e(asset('calendar/main.css')); ?>" rel='stylesheet' />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel="stylesheet" href="css/admin_custom.css">
    
    <style>
        html,body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 14px;
        }

        #calendar {
            width: 95%;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://kit.fontawesome.com/1e766aad6d.js" crossorigin="anonymous"></script>

    <!-- Scripts Fullcalendar -->
    <script src="<?php echo e(asset('calendar/main.js')); ?>"></script>
    <script src="<?php echo e(asset('js/calendar.js')); ?>"></script>

    <script>
        var calendarEl = document.getElementById('calendar');
        var calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'listWeek',

        views: {
            listDay: { buttonText: 'Citas de hoy' },
            listWeek: { buttonText: 'Citas de la semana' },
            listMonth: { buttonText: 'Citas del mes' }
        },

        headerToolbar: {
            left: 'title',
            center: '',
            right: 'listDay,listWeek,listMonth'
        },
        events: "<?php echo e(url('/agenda/show')); ?>"
        });
        
        calendar.setOption('locale', 'es');        
        calendar.setOption('height', 560);
        calendar.render();
    </script>
<?php $__env->stopSection(); ?>
</script>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PsychoSoft_1\resources\views/agenda/events.blade.php ENDPATH**/ ?>
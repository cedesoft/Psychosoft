

<?php $__env->startSection('title', 'Calendario'); ?>

<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('h-d-paciente-table')->html();
} elseif ($_instance->childHasBeenRendered('m0z0cWK')) {
    $componentId = $_instance->getRenderedChildComponentId('m0z0cWK');
    $componentTag = $_instance->getRenderedChildComponentTagName('m0z0cWK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('m0z0cWK');
} else {
    $response = \Livewire\Livewire::mount('h-d-paciente-table');
    $html = $response->html();
    $_instance->logRenderedChild('m0z0cWK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <link rel="stylesheet" href="css/admin_custom.css">
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PsychoSoft_1\resources\views/pacientes/enable_disable.blade.php ENDPATH**/ ?>
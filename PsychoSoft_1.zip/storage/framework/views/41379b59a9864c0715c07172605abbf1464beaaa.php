<div>
    <div class="p-2">
        <?php if($paciente == null): ?>
    <div class="d-flex align-items-center">
        <strong>Cargando...</strong>
        <div class="spinner-border ms-auto" role="status" aria-hidden="true"></div>
      </div>
    <?php else: ?>
        <form wire:submit.prevent='submit' class="row g-3" autocomplete="off">
            <?php if(session()->has('success')): ?>
            <?php endif; ?>
            <div class="col-md-4">
                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;font-size:10px;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-label-group in-border">
                    <label for="nombre" class="form-label">Nombre del Paciente</label>
                    <input type="text" name="nombre" class="form-control"
                        wire:model='nombre' placeholder="<?php echo e($paciente->nombre); ?>"/>
                </div>
            </div>
            <div class="col-md-4">
                <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;font-size:10px;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-label-group in-border">
                    <label for="apellidos" class="form-label">Apellidos</label>
                    <input type="text" name="apellidos" class="form-control"
                        wire:model='apellidos' placeholder="<?php echo e($paciente->apellidos); ?>"/>
                </div>
            </div>
            <div class="col-md-4">
                <?php $__errorArgs = ['domicilio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;font-size:10px;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-label-group in-border">
                    <label for="domicilio" class="form-label">Domicilio</label>
                    <input type="text" name="domicilio" class="form-control"
                        wire:model='domicilio' placeholder="<?php echo e($paciente->domicilio); ?>" />
                </div>
            </div>
            <div class="col-md-3">
                <?php $__errorArgs = ['nacimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;font-size:10px;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-label-group in-border">
                    <label for="nacimiento" class="form-label">Fecha Nacimiento</label>
                    <input type="text" name="nacimiento" class="form-control"
                        wire:model='nacimiento' placeholder="<?php echo e($paciente->fecha_nacimiento); ?>" />
                </div>
            </div>

            <div class="col-md-2">
                <?php $__errorArgs = ['edad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;font-size:10px;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-label-group in-border">
                    <label for="edad" class="form-label">Edad</label>
                    <input type="text" name="edad" class="form-control" wire:model='edad' placeholder="<?php echo e($paciente->edad); ?>" />
                </div>
            </div>
            <div class="col-md-3">
                <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;font-size:10px;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-label-group in-border">
                    <label for="telefono" class="form-label">Teléfono</label>
                    <input type="tel" maxlength="10" minlength="10" name="telefono" class="form-control" wire:model='telefono' placeholder="<?php echo e($paciente->telefono_correo); ?>" />
                </div>
            </div>
            <div class="col-md-4">
                <?php $__errorArgs = ['escolaridad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;font-size:10px;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-label-group in-border">
                    <label for="escolaridad" class="form-label_1">Escolaridad</label>
                    <select name="escolaridad" class="custom-select form-control" wire:model='escolaridad'>
                        <option selected>Seleccione una opcion...</option>
                        <option value="Preescolar">Preescolar</option>
                        <option value="Primaria">Primaria</option>
                        <option value="Secundaria">Secundaria</option>
                        <option value="Preparatoria">Preparatoria</option>
                        <option value="Licenciatura">Licenciatura</option>
                        <option value="Doctorado">Doctorado</option>
                        <option value="Ninguna">Ninguno</option>
                    </select>
                </div>
            </div>
            <div class="col-md-4">
                <?php $__errorArgs = ['ocupacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;font-size:10px;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-label-group in-border">
                    <label for="ocupacion" class="form-label">Ocupación</label>
                    <input type="text" maxlength="10" minlength="10" name="ocupacion" class="form-control" wire:model='ocupacion' placeholder="<?php echo e($ficha->ocupacion); ?>" />
                </div>
            </div>
            <div class="col-md-4">
                <?php $__errorArgs = ['estado_civil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;font-size:10px;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-label-group in-border">
                    <label for="edoCivil" class="form-label_1">Estado Civil</label>
                    <select name="edoCivil" class="custom-select form-control" wire:model='estado_civil'>
                        <option selected>Seleccione una opcion...</option>
                        <option value="Soltero(a)">Soltero(a)</option>
                        <option value="Divociado(a)">Divociado(a)</option>
                        <option value="Viudo(a)">Viudo(a)</option>
                        <option value="Casado(a)">Casado(a)</option>
                    </select>
                </div>
            </div>
            <div class="col-md-4">
                <?php $__errorArgs = ['adicciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;font-size:10px;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-label-group in-border">
                    <label for="adicciones" class="form-label">Adicciones</label>
                    <input type="text" name="adicciones" class="form-control"
                        wire:model='adicciones' placeholder="<?php echo e($ficha->adicciones); ?> "/>
                </div>
            </div>
            <div class="col-md-3">
                <?php $__errorArgs = ['religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;font-size:10px;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-label-group in-border">
                    <label for="religion" class="form-label">Religión</label>
                    <input type="text" name="religion" class="form-control" wire:model='religion' placeholder="<?php echo e($ficha->religion); ?>" />
                </div>
            </div>

            <div class="col-md-4">
                <?php $__errorArgs = ['vive_con'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;font-size:10px;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-label-group in-border">
                    <label for="viveCon" class="form-label">Personas con quien vive</label>
                    <input type="text" name="viveCon" class="form-control"
                        wire:model='vive_con' placeholder="<?php echo e($ficha->vive_con); ?>" />
                </div>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary w-100"
                    style="border-radius: 12px; background-color: blue;margin-top:30px !important">Actualizar</button>
            </div>
            <div class="col-md-2">
                <button type="reset" class="btn btn-dark w-100" data-bs-dismiss="modal" aria-label="Close"
                    style="border-radius: 12px;background-color: black;margin-top:30px !important">Cancelar</button>
            </div>
        </form>
    <?php endif; ?>
        
    </div>
</div><?php /**PATH C:\xampp\htdocs\PsychoSoft_1\resources\views/livewire/form-edit-ficha-paciente.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Calendario'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white pt-1 pe-2 ps-2 pb-1 rounded-3">
    <div class="card border-light mt-2" style="border-radius: 20px;">
		<div class="card-header bg-primary"  style="border-radius: 15px;">
			Ficha de Identificación
		</div>
      	<div class="card-body">
			
			<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('ficha-paciente')->html();
} elseif ($_instance->childHasBeenRendered('5kM2lzc')) {
    $componentId = $_instance->getRenderedChildComponentId('5kM2lzc');
    $componentTag = $_instance->getRenderedChildComponentTagName('5kM2lzc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5kM2lzc');
} else {
    $response = \Livewire\Livewire::mount('ficha-paciente');
    $html = $response->html();
    $_instance->logRenderedChild('5kM2lzc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
		</div>
	</div>
	<hr class="bg-primary">
	<div class="card border-light mt-2" style="border-radius: 20px;">
		<div class="card-header bg-purple" style="border-radius: 15px;">
			Expediente Médico
		</div>
      	<div class="card-body">
			<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('expediente-medico')->html();
} elseif ($_instance->childHasBeenRendered('glRueMw')) {
    $componentId = $_instance->getRenderedChildComponentId('glRueMw');
    $componentTag = $_instance->getRenderedChildComponentTagName('glRueMw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('glRueMw');
} else {
    $response = \Livewire\Livewire::mount('expediente-medico');
    $html = $response->html();
    $_instance->logRenderedChild('glRueMw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

    <link rel="stylesheet" href="css/admin_custom.css">
	<link rel="stylesheet" href=<?php echo e(asset('css/floating-labels.css')); ?>>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"
	  integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
	<link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
		integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
		<?php echo \Livewire\Livewire::styles(); ?>

	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PsychoSoft_1\resources\views/pacientes/index.blade.php ENDPATH**/ ?>
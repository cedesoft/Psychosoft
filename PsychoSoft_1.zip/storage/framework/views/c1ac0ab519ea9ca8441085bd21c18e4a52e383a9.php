<div>
  <div class="flex flex-col">
    <div class="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-3">
      <div class="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-3">
        <div class="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
          <div class="bg-white px-3 py-3 items-center justify-between border-t border-gray-200 sm:px-6">
            <div class="flex text-gray-500">
              <select wire:model='perPage'
                class="focus:ring-indigo-500 focus:border-indigo-500 shadow-sm sm:text-sm border-gray-300 rounded-md">
                <option value="5">5</option>
                <option value="10">10</option>
                <option value="15">15</option>
                <option value="20">20</option>
              </select>
              <input type="text"
                class="focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md ml-3"
                wire:model='search' placeholder="Buscar...">
              <button
                class="focus:ring-indigo-500 w-10 focus:border-indigo-500 shadow-sm sm:text-sm border-green-500 rounded-lg ml-3"
                wire:click="clear">
                <span class="fa fa-eraser"></span>
              </button>
            </div>
          </div>
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th scope="col" class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  ID
                </th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Nombre
                  <button wire:click="sortable('nombre')">
                    <span class="fa fa<?php echo e($field === 'nombre' ? $icon: '-circle'); ?>"></span>
                  </button>
                </th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Edad

                  <button wire:click="sortable('edad')">
                    <span class="fa fa<?php echo e($field === 'edad' ? $icon: '-circle'); ?>"></span>
                  </button>
                </th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Domicilio
                </th>
                <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Fecha de Registro

                  <button wire:click="sortable('created_at')">
                    <span class="fa fa<?php echo e($field === 'created_at' ? $icon: '-circle'); ?>"></span>
                  </button>
                </th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
              <?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td class="px-3 py-2 whitespace-nowrap text-sm text-gray-500">
                  <?php echo e($paciente->id); ?>

                </td>
                <td class="px-6 py-2 whitespace-nowrap">
                  <div class="flex items-center">
                    <div class="flex-shrink-0 h-10 w-10">

                      <img class="h-10 w-10 rounded-full"
                        src="https://ui-avatars.com/api/?name=<?php echo e($paciente->nombre); ?>&&background=000000&color=fff&&bold=true"
                        alt="">
                    </div>
                    <div class="ml-3">
                      <div class="text-sm font-medium text-gray-900">
                        <?php echo e($paciente->nombre); ?>

                      </div>
                      <div class="text-sm text-gray-500">
                        <?php echo e($paciente->apellidos); ?>

                      </div>
                    </div>
                  </div>
                </td>
                <td class="px-6 py-2 whitespace-nowrap">
                  <div class="text-sm text-gray-900"><?php echo e($paciente->edad); ?></div>
                </td>
                <td class="px-6 py-2 whitespace-nowrap">
                  <div class="text-sm font-medium text-gray-900">
                    <?php echo e($paciente->domicilio); ?>

                  </div>
                  <span
                    class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                    +52 <?php echo e($paciente->telefono_correo); ?>

                  </span>
                </td>
                <td class="px-4 py-2 whitespace-nowrap text-sm text-gray-500">
                  <?php echo e($paciente->created_at); ?>

                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <!-- More items... -->
            </tbody>
          </table>
          <div class="bg-white px-3 py-2 items-center justify-between border-t border-gray-200 sm:px-6">
            <?php echo e($pacientes->links()); ?>

          </div>
        </div>
      </div>
    </div>
  </div>

</div>
</td><?php /**PATH C:\xampp\htdocs\PsychoSoft_1\resources\views/livewire/pacientes-table.blade.php ENDPATH**/ ?>
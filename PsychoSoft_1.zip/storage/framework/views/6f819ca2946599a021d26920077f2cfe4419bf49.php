

<?php $__env->startSection('title', 'Calendario'); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('edit-paciente-table')->html();
} elseif ($_instance->childHasBeenRendered('Uk4FXPZ')) {
    $componentId = $_instance->getRenderedChildComponentId('Uk4FXPZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('Uk4FXPZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Uk4FXPZ');
} else {
    $response = \Livewire\Livewire::mount('edit-paciente-table');
    $html = $response->html();
    $_instance->logRenderedChild('Uk4FXPZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <link rel="stylesheet" href="css/admin_custom.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
<?php echo \Livewire\Livewire::scripts(); ?>

<script>
    window.addEventListener('closeModal', event => {
        $('#modalForm').modal('hide');
    })
    window.addEventListener('closeModal2', event => {
        $('#modalForm2').modal('hide');
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PsychoSoft_1\resources\views/pacientes/edit.blade.php ENDPATH**/ ?>